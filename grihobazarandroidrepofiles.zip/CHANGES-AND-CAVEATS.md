# GrihobazarApp — what was fixed, and what still needs a decision

This is a **WebView wrapper** — a native Android app with a browser view inside it,
pointed at `grihobazar.in`. That is a different approach from the Trusted Web
Activity route in `../LAUNCH-ANDROID-APP.md`. Read "Which approach" at the bottom
before investing more in it.

---

## It could not build as uploaded

Two hard failures, both confirmed by checking the files rather than guessing:

| Problem | Effect |
|---|---|
| `AndroidManifest.xml` referenced `@mipmap/ic_launcher` and `@mipmap/ic_launcher_round`, but the ZIP contained **no `mipmap` resources at all** | `aapt2` fails: *resource mipmap/ic_launcher not found*. Nothing compiles. |
| `gradle/wrapper/gradle-wrapper.properties` was present but `gradlew`, `gradlew.bat` and `gradle-wrapper.jar` were all missing | The README's `./gradlew assembleDebug` fails immediately. |

Both are fixed.

---

## What changed

### Build blockers

- **Launcher icons added** for all five densities, generated from the site's own
  `icons/icon-48…192.png` — so the app icon is the real Grihobazar mark, not a
  placeholder. Also added an **adaptive icon** (`mipmap-anydpi-v26/`) using the
  `maskable-*` art, which already has the safe-zone padding Android 8+ requires,
  over the brand red.
- **Gradle wrapper restored** at the 8.4 version the project already specified.

### Correctness

- **`TARGET_URL` changed from `https://www.grihobazar.in` to `https://grihobazar.in`.**
  `netlify.toml` 301-redirects `www` to the apex, so every cold start was paying
  for a redirect.
- **`window.open()` now works.** The site's social share buttons call it
  (`index.html` line ~2708). A WebView without `setSupportMultipleWindows(true)`
  silently swallows that call — the buttons did nothing at all. Popups are now
  handed to the system browser or share sheet via `onCreateWindow`.
- **UPI and other app links no longer dead-end.** `handleExternalUrls` only knew
  about `tel:`, `mailto:`, `geo:` and WhatsApp. Anything else non-web — including
  the `upi:` handoff a Razorpay payment depends on — was loaded *as a web page*
  and rendered an error. Any non-`http(s)` scheme now goes to the system.
  `http`/`https` deliberately stay in the WebView so Razorpay's own checkout
  pages don't get kicked out mid-payment.
- **Portrait locked**, matching `"orientation": "portrait-primary"` in the site's
  `manifest.json`, so the app and the installed PWA behave the same way.

### Privacy and Play policy

- **Location permissions removed.** The manifest requested `ACCESS_FINE_LOCATION`
  and `ACCESS_COARSE_LOCATION`, and `onGeolocationPermissionsShowPrompt`
  auto-granted geolocation to any origin without asking. The site calls
  `navigator.geolocation` **zero times** — so this was a Play Console
  prominent-disclosure obligation, and a privacy smell, for a feature that
  doesn't exist. It also never requested the Android runtime permission, so it
  could not have worked anyway.
- **`usesCleartextTraffic="true"` removed.** The site is HTTPS-only; this only
  permitted plaintext HTTP.

### Quality

- **Progress bar overlaid** instead of the WebView being laid out below it. As
  written, the page shifted down 4dp every time a load started.
- **Hardcoded UI strings replaced with the string resources** that were already
  defined and unused. Worth having if you ever want a Bengali translation.
- **`NetworkInfo`/`isConnectedOrConnecting()`** (deprecated since API 29)
  replaced with `NetworkCapabilities`.
- **`setLayerType(LAYER_TYPE_HARDWARE)` removed.** WebView is already hardware
  accelerated; forcing a hardware layer on a scrolling view can cause rendering
  artifacts. The README listed this as a feature; it wasn't doing what it claimed.
- **`androidx.activity` declared explicitly.** `MainActivity` uses
  `OnBackPressedCallback` and `ActivityResultContracts` directly; it was relying
  on appcompat's transitive graph.
- **Forced `EXTRA_ALLOW_MULTIPLE` removed** from the file chooser —
  `createIntent()` already honours whether the `<input>` accepts multiple files.

---

## ⚠️ Not verified by a compiler

**None of this has been compiled.** The environment it was edited in has no
Android SDK, and the network policy blocks `dl.google.com` (and
`maven.google.com`, which redirects there), so the SDK cannot be installed.

What *was* verified:

- every XML file parses
- every `@string/`, `@color/`, `@drawable/`, `@mipmap/`, `@style/` and `R.*`
  reference resolves to something that exists — the exact check the original
  project fails
- all icon PNGs are present at the right density and dimensions

The first real compile will happen on your machine. If Android Studio reports an
error, paste it and it can be fixed.

---

## 🔴 Still blocking a Play Store release: `targetSdk`

`compileSdk` and `targetSdk` are **34**. Google Play requires new apps and
updates to target a recent API level — the bar rises every August, and 34 is
well below it now. **Play will reject the upload.**

This was deliberately not patched here, because raising it is not a one-line
change:

1. `targetSdk 35+` requires a newer Android Gradle Plugin than the 8.2.2 this
   project pins, which in turn requires a newer Gradle.
2. Android 15 (API 35) **enforces edge-to-edge**. `android:statusBarColor` in
   `themes.xml` stops working, and the WebView will draw underneath the status
   bar unless window insets are handled in code.

Picking those version numbers blind, with no way to compile, would likely trade
one clear error for several confusing ones. Do it in Android Studio instead —
**Tools → AGP Upgrade Assistant** proposes the correct matched versions and
applies them. Then check the top of the app isn't hidden behind the status bar,
and ask for the insets fix if it is.

Play Console tells you the exact required API level when you upload.

---

## Which approach: WebView wrapper or Trusted Web Activity?

| | This project (WebView) | TWA via PWABuilder |
|---|---|---|
| Play Store policy risk | **Higher.** Google's Minimum Functionality policy targets apps that mainly repackage a website; a WebView wrapper is the textbook case | **Lower.** A TWA is Google's own sanctioned mechanism for exactly this |
| Address bar | Never shows | Needs `assetlinks.json` set up once |
| Browser engine | System WebView — no Chrome autofill, no shared login with Chrome, `navigator.share` unavailable | Real Chrome — everything the site already relies on works |
| Razorpay payments | Needs the popup and UPI handling added above, and still carries more risk | Runs in Chrome, same as the website |
| Maintenance | ~270 lines of Java you own and must keep building | Regenerated in ten minutes, no code |
| Needs Android Studio | **Yes** — a multi-gigabyte install | No |
| Extra native features | Pull-to-refresh, native offline screen, native file picker | Not available |

**Recommendation: the TWA.** Chiefly the policy risk and the maintenance burden —
for someone who doesn't write code, owning a Java app you can't debug is a
liability, and the WebView route's one real advantage (no `assetlinks.json`
step) is a ten-minute task done once.

Keep this project if you specifically want pull-to-refresh and the native
offline screen, and accept the review risk. It is in a buildable state now
either way.
